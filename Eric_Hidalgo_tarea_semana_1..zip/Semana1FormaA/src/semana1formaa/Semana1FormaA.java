/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana1formaa;

/**
 *
 * Eric Hidalgo
 */
public class Semana1FormaA {

    public static void main(String[] args) {

        Pedido pedido1 = new PedidoComida(1, "Av Central 123");
        Pedido pedido2 = new PedidoEncomienda(2, "Calle Norte 456");
        Pedido pedido3 = new PedidoExpress(3, "Av Sur 789");

        pedido1.asignarRepartidor();
        pedido1.asignarRepartidor("Valentina");

        System.out.println();

        pedido2.asignarRepartidor();
        pedido2.asignarRepartidor("Diego");

        System.out.println();

        pedido3.asignarRepartidor();
        pedido3.asignarRepartidor("Antonia");
    }
}
